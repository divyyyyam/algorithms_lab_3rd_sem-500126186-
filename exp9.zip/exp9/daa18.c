// backtracking approach knapsack
#include <stdio.h>

int maxProfitBacktracking(int W, int wt[], int val[], int n, int index, int currentWeight, int currentProfit) {
    if (index == n) {
        return currentProfit;
    }

    int include = 0;
    if (currentWeight + wt[index] <= W) {
        include = maxProfitBacktracking(W, wt, val, n, index + 1, currentWeight + wt[index], currentProfit + val[index]);
    }

    int exclude = maxProfitBacktracking(W, wt, val, n, index + 1, currentWeight, currentProfit);

    return (include > exclude) ? include : exclude;
}

int knapsackBacktracking(int W, int wt[], int val[], int n) {
    return maxProfitBacktracking(W, wt, val, n, 0, 0, 0);
}

int main() {
    int W = 50;
    int wt[] = {10, 20, 30};
    int val[] = {60, 100, 120};
    int n = sizeof(wt) / sizeof(wt[0]);

    printf("Maximum Profit (Backtracking): %d\n", knapsackBacktracking(W, wt, val, n));
    return 0;
}

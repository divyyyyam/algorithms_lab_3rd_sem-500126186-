//knapsack branch and bound approach
#include <stdio.h>

struct Item {
    int weight;
    int value;
};

int max(int a, int b) {
    return (a > b) ? a : b;
}

int bound(int W, struct Item arr[], int n, int i, int currentWeight, int currentValue) {
    if (currentWeight >= W) return 0;
    
    int totalValue = currentValue;
    int j = i;
    while (j < n && currentWeight + arr[j].weight <= W) {
        currentWeight += arr[j].weight;
        totalValue += arr[j].value;
        j++;
    }

    if (j < n) {
        totalValue += (W - currentWeight) * arr[j].value / arr[j].weight;
    }
    return totalValue;
}

void knapsackBranchBound(struct Item arr[], int W, int n) {
    int maxProfit = 0;
    int currentWeight = 0;
    int currentValue = 0;
    int i = 0;

    while (i < n) {
        if (currentWeight + arr[i].weight <= W) {
            currentWeight += arr[i].weight;
            currentValue += arr[i].value;
            maxProfit = max(maxProfit, currentValue);
        }

        if (bound(W, arr, n, i + 1, currentWeight, currentValue) > maxProfit) {
            i++;
        } else {
            break;
        }
    }

    printf("Maximum Profit (Branch & Bound): %d\n", maxProfit);
}

int main() {
    int W = 50;
    struct Item arr[] = {{10, 60}, {20, 100}, {30, 120}};
    int n = sizeof(arr) / sizeof(arr[0]);
    
    knapsackBranchBound(arr, W, n);
    return 0;
}

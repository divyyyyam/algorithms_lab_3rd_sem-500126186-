//job scheduling
#include <stdio.h>
#include <stdlib.h>

struct Item
{
    int weight;
    int value;
};
int compare(const void *a, const void *b)
{
    double ratio1 = (double)(((struct Item *)a)->value) / ((struct Item *)a)->weight;
    double ratio2 = (double)(((struct Item *)b)->value) / ((struct Item *)b)->weight;
    if (ratio1 > ratio2)
        return -1;
    if (ratio1 < ratio2)
        return 1;
    return 0;
}
double Knapsack(struct Item items[], int n, int capacity){
    qsort(items, n, sizeof(struct Item), compare);
    double maxValue = 0.0;
    int currentWeight = 0;
    for (int i = 0; i < n; i++){
        if (currentWeight + items[i].weight <= capacity){
            currentWeight += items[i].weight;
            maxValue += items[i].value;
        }
        else{
            double remainingCapacity = capacity - currentWeight;
            maxValue += (remainingCapacity / items[i].weight) * items[i].value;
            break;
        }
    }
    return maxValue;
}

int main(){
    struct Item items[]={
        {10, 60},
        {20, 100},
        {30, 120}};

    int n = sizeof(items) / sizeof(items[0]);
    int capacity = 50;
    double maxValue = Knapsack(items, n, capacity);
    printf("Maximum value in the knapsack: %.2lf\n", maxValue);
}

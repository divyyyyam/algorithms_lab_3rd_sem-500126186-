// knapsack greedy
#include <stdio.h>

typedef struct {
    int weight, value;
    float ratio;
} Item;

void greedyKnapsack(Item items[], int n, int capacity) {
    int totalValue = 0, totalWeight = 0;

    for (int i = 0; i < n; i++) {
        items[i].ratio = (float)items[i].value / items[i].weight;
    }

    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (items[j].ratio < items[j + 1].ratio) {
                Item temp = items[j];
                items[j] = items[j + 1];
                items[j + 1] = temp;
            }
        }
    }

    for (int i = 0; i < n; i++) {
        if (totalWeight + items[i].weight <= capacity) {
            totalWeight += items[i].weight;
            totalValue += items[i].value;
        }
    }

    printf("Greedy Approach - Total Value: %d\n", totalValue);
}

int main() {
    Item items[] = {{10, 60}, {20, 100}, {30, 120}};
    int n = sizeof(items) / sizeof(items[0]);
    int capacity = 50;

    greedyKnapsack(items, n, capacity);

    return 0;
}

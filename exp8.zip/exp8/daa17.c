//sum of subset
#include <stdio.h>

void sumOfSubsets(int set[], int subset[], int n, int index, int currentSum, int target) {
    if (currentSum == target) {
        for (int i = 0; i < index; i++) {
            printf("%d ", subset[i]);
        }
        printf("\n");
        return;
    }

    if (index >= n || currentSum > target) {
        return;
    }

    subset[index] = set[index];
    sumOfSubsets(set, subset, n, index + 1, currentSum + set[index], target);
    sumOfSubsets(set, subset, n, index + 1, currentSum, target);
}

int main() {
    int set[] = {10, 7, 5, 18, 12, 20, 15};
    int target = 35;
    int n = sizeof(set) / sizeof(set[0]);
    int subset[n];

    sumOfSubsets(set, subset, n, 0, 0, target);

    return 0;
}

// iterative approach to insert an element in BST
#include <stdio.h>
#include <stdlib.h>

struct Node {
    int data;
    struct Node* left;
    struct Node* right;
};

struct Node* newNode(int data) {
    struct Node* node = (struct Node*)malloc(sizeof(struct Node));
    node->data = data;
    node->left = NULL;
    node->right = NULL;
    return node;
}

struct Node* insert_iterative(struct Node* root, int key) {
    struct Node* new_node = newNode(key);
    
    if (root == NULL)
        return new_node;

    struct Node* parent = NULL;
    struct Node* current = root;

    while (current != NULL) {
        parent = current;
        if (key < current->data)
            current = current->left;
        else if (key > current->data)
            current = current->right;
        else
            return root;
    }

    if (key < parent->data)
        parent->left = new_node;
    else
        parent->right = new_node;

    return root;
}

void inorder(struct Node* root) {
    if (root != NULL) {
        inorder(root->left);
        printf("%d ", root->data);
        inorder(root->right);
    }
}

int main() {
    struct Node* root = NULL;
    root = insert_iterative(root, 50);
    insert_iterative(root, 30);
    insert_iterative(root, 20);
    insert_iterative(root, 40);
    insert_iterative(root, 70);
    insert_iterative(root, 60);
    insert_iterative(root, 80);

    printf("In-order traversal of the BST: ");
    inorder(root);

    return 0;
}

// recursive approach to insert an element in BST
#include <stdio.h>
#include <stdlib.h>

struct Node {
    int data;
    struct Node* left;
    struct Node* right;
};

struct Node* newNode(int data) {
    struct Node* node = (struct Node*)malloc(sizeof(struct Node));
    node->data = data;
    node->left = NULL;
    node->right = NULL;
    return node;
}

struct Node* insert_recursive(struct Node* root, int key) {
    if (root == NULL) {
        return newNode(key);
    }

    if (key < root->data)
        root->left = insert_recursive(root->left, key);
    else if (key > root->data)
        root->right = insert_recursive(root->right, key);

    return root;
}

void inorder(struct Node* root) {
    if (root != NULL) {
        inorder(root->left);
        printf("%d ", root->data);
        inorder(root->right);
    }
}

int main() {
    struct Node* root = NULL;
    root = insert_recursive(root, 50);
    insert_recursive(root, 30);
    insert_recursive(root, 20);
    insert_recursive(root, 40);
    insert_recursive(root, 70);
    insert_recursive(root, 60);
    insert_recursive(root, 80);

    printf("In-order traversal of the BST: ");
    inorder(root);

    return 0;
}

#include <stdio.h> //Merge sort
void compare(int arr1[],int arr2[],int arr3[]){
    int x=0, y=0,z=0;
    while(x<5 && y<5){
        if (arr1[x]<arr2[y]) {
            arr3[z++]=arr1[x++];
        } else{
            arr3[z++]=arr2[y++];
        }
        
    }
        while(x<5){
        arr3[z++]=arr1[x++];
        
    }

        while(y<5) {
        arr3[z++]=arr2[y++];
    
    }

    }


int main()
{
    int arr1[5] = {1,3,5,7,9};
    int arr2[5] = {2,4,6,8,10};
    int arr3[10];
     compare(arr1,arr2,arr3);
    for(int i =0;i<10;i++){
        printf("%d \t",arr3[i]);
    }
    return 0;
    
}
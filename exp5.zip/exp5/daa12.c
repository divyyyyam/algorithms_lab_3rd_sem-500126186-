//matrix chain multiplication
#include <stdio.h>
#include <limits.h>

void matrixChainMultiplication(int dims[], int n) {
    int dp[n][n];
    int split[n][n];

    for (int i = 1; i < n; i++) {
        dp[i][i] = 0;
    }

    for (int chain_len = 2; chain_len < n; chain_len++) {
        for (int i = 1; i < n - chain_len + 1; i++) {
            int j = i + chain_len - 1;
            dp[i][j] = INT_MAX;
            for (int k = i; k < j; k++) {
                int cost = dp[i][k] + dp[k + 1][j] + dims[i - 1] * dims[k] * dims[j];
                if (cost < dp[i][j]) {
                    dp[i][j] = cost;
                    split[i][j] = k;
                }
            }
        }
    }

    printf("Minimum number of multiplications: %d\n", dp[1][n - 1]);

    void printOptimalParenthesis(int i, int j) {
        if (i == j) {
            printf("A%d", i);
        } else {
            printf("(");
            printOptimalParenthesis(i, split[i][j]);
            printOptimalParenthesis(split[i][j] + 1, j);
            printf(")");
        }
    }

    printf("Optimal parenthesis placement: ");
    printOptimalParenthesis(1, n - 1);
    printf("\n");
}

int main() {
    int dims[] = {40, 20, 30, 10, 30};
    int n = sizeof(dims) / sizeof(dims[0]);

    matrixChainMultiplication(dims, n);

    return 0;
}
